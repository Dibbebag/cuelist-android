const { contextBridge, ipcRenderer } = require("electron");
// stessa interfaccia del plugin Android: l'app usa window.cueNative
const call = (ch) => async (a) => {
  const r = await ipcRenderer.invoke(ch, a);
  if (r && r.canceled) throw new Error("annullato");
  return r;
};
contextBridge.exposeInMainWorld("cueNative", {
  platform: "win32",
  driver: ipcRenderer.sendSync("getDriverSync"),
  folderInfo: call("folderInfo"),
  pickAudio: call("pickAudio"),
  pickFolder: call("pickFolder"),
  scanSaved: call("scanSaved"),
  findAudio: call("findAudio"),
  saveFile: call("saveFile"),
  writeAuto: call("writeAuto"),
  listShows: call("listShows"),
  readShow: call("readShow"),
  writeState: call("writeState"),
  readState: call("readState"),
  readBinary: (a) => ipcRenderer.invoke("readBinary", a && a.path),
  getDriver: () => ipcRenderer.invoke("getDriver"),
  setDriver: (a) => ipcRenderer.invoke("setDriver", a),
  openSound: () => ipcRenderer.invoke("openSound"),
  remoteGet: () => ipcRenderer.invoke("remoteGet"),
  remoteSet: (a) => ipcRenderer.invoke("remoteSet", a),
  remoteNewPin: () => ipcRenderer.invoke("remoteNewPin"),
  remoteState: (s) => ipcRenderer.send("remote:state", s),
  onRemoteCmd: (cb) => ipcRenderer.on("remote:cmd", (_e, c) => cb(c)),
  updCheck: () => ipcRenderer.invoke("updCheck"),
  updInstall: () => ipcRenderer.invoke("updInstall"),
  onUpdProgress: (cb) => ipcRenderer.on("upd:progress", (_e, p) => cb(p)),
  asioInfo: () => ipcRenderer.invoke("asioInfo"),
  asioDevices: () => ipcRenderer.invoke("asioDevices"),
  asioOpen: (a) => ipcRenderer.invoke("asioOpen", a),
  asioProbe: (a) => ipcRenderer.invoke("asioProbe", a),
  asioWrite: (b) => ipcRenderer.send("asio:data", b)
});
