// Cue List per Windows (Electron): finestra, cartella CueList, scelta del driver audio
const { app, BrowserWindow, ipcMain, dialog, shell, session, Menu, utilityProcess } = require("electron");
const path = require("path");
const fs = require("fs");
const { exec } = require("child_process");

const cfgFile = path.join(app.getPath("userData"), "config.json");
const readCfg = () => { try { return JSON.parse(fs.readFileSync(cfgFile, "utf8")); } catch (e) { return {}; } };
const writeCfg = (c) => { try { fs.mkdirSync(path.dirname(cfgFile), { recursive: true }); fs.writeFileSync(cfgFile, JSON.stringify(c)); } catch (e) {} };
const cfg = readCfg();

// Driver audio di Chromium su Windows (si applica all'avvio)
if (process.platform === "win32") {
  if (cfg.driver === "exclusive") app.commandLine.appendSwitch("enable-exclusive-audio");
  if (cfg.driver === "wave") app.commandLine.appendSwitch("force-wave-audio");
}
app.commandLine.appendSwitch("autoplay-policy", "no-user-gesture-required");
app.commandLine.appendSwitch("disable-renderer-backgrounding");

let win = null;
const safe = (n) => String(n || "").replace(/[\\/:*?"<>|]/g, "_");
const root = () => {
  const r = path.join(app.getPath("documents"), "CueList");
  for (const s of ["Show", "Brani", "Autosalvataggi"]) fs.mkdirSync(path.join(r, s), { recursive: true });
  return r;
};
const sub = (n) => path.join(root(), n);
const kindDir = (k) => sub(k === "auto" ? "Autosalvataggi" : "Show");

function scan(dir, wanted, out, done, depth) {
  if (depth > 6) return;
  let list = [];
  try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
  for (const d of list) {
    const p = path.join(dir, d.name);
    if (d.isDirectory()) { scan(p, wanted, out, done, depth + 1); continue; }
    const low = d.name.toLowerCase();
    if (wanted.has(low) && !done.has(low)) {
      try {
        const dest = path.join(sub("Brani"), safe(d.name));
        if (path.resolve(p) !== path.resolve(dest)) fs.copyFileSync(p, dest);
        done.add(low);
        out.push({ name: d.name, path: dest });
      } catch (e) {}
    }
  }
}
function scanFolders(folders, names) {
  const wanted = new Set((names || []).map((n) => String(n).toLowerCase()));
  const out = [], done = new Set();
  for (const f of folders) scan(f, wanted, out, done, 0);
  return { files: out };
}

ipcMain.handle("folderInfo", () => ({ path: root() }));
ipcMain.handle("pickAudio", async (_e, a) => {
  const r = await dialog.showOpenDialog(win, {
    properties: ["openFile"].concat(a && a.multiple ? ["multiSelections"] : []),
    filters: [{ name: "Audio", extensions: ["wav", "mp3", "flac", "ogg", "aac", "m4a", "aif", "aiff"] }, { name: "Tutti i file", extensions: ["*"] }]
  });
  if (r.canceled || !r.filePaths.length) return { canceled: true };
  const files = [];
  for (const f of r.filePaths) {
    const dest = path.join(sub("Brani"), safe(path.basename(f)));
    if (path.resolve(f) !== path.resolve(dest)) fs.copyFileSync(f, dest);
    files.push({ name: path.basename(f), path: dest });
  }
  return { files };
});
ipcMain.handle("pickFolder", async (_e, a) => {
  const r = await dialog.showOpenDialog(win, { properties: ["openDirectory"] });
  if (r.canceled || !r.filePaths.length) return { canceled: true };
  const c = readCfg();
  c.folders = Array.from(new Set((c.folders || []).concat(r.filePaths)));
  writeCfg(c);
  return scanFolders(r.filePaths, a && a.names);
});
ipcMain.handle("scanSaved", (_e, a) => scanFolders(readCfg().folders || [], a && a.names));
ipcMain.handle("findAudio", (_e, a) => {
  const f = path.join(sub("Brani"), safe(a && a.name));
  return fs.existsSync(f) ? { path: f } : {};
});
ipcMain.handle("saveFile", async (_e, a) => {
  const name = safe((a && a.name) || "show.json");
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(sub("Show"), name), filters: [{ name: "Show Cue List", extensions: ["json"] }] });
  if (r.canceled || !r.filePath) return { canceled: true };
  fs.writeFileSync(r.filePath, a.text || "", "utf8");
  try { fs.writeFileSync(path.join(sub("Show"), name), a.text || "", "utf8"); } catch (e) {}
  return {};
});
ipcMain.handle("writeAuto", (_e, a) => {
  const dir = sub("Autosalvataggi");
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const name = "auto-" + stamp + ".json";
  fs.writeFileSync(path.join(dir, name), (a && a.text) || "", "utf8");
  const all = fs.readdirSync(dir).map((n) => ({ n, t: fs.statSync(path.join(dir, n)).mtimeMs })).sort((x, y) => y.t - x.t);
  for (const o of all.slice(10)) { try { fs.unlinkSync(path.join(dir, o.n)); } catch (e) {} }
  return { name };
});
ipcMain.handle("listShows", (_e, a) => {
  const dir = kindDir(a && a.kind);
  const files = fs.readdirSync(dir)
    .map((n) => ({ name: n, modified: fs.statSync(path.join(dir, n)).mtimeMs }))
    .sort((x, y) => y.modified - x.modified);
  return { files };
});
ipcMain.handle("readShow", (_e, a) => ({ text: fs.readFileSync(path.join(kindDir(a && a.kind), safe(a && a.name)), "utf8") }));
ipcMain.handle("writeState", (_e, a) => { fs.writeFileSync(path.join(root(), "ultimo-stato.json"), (a && a.text) || "", "utf8"); return {}; });
ipcMain.handle("readState", () => {
  const f = path.join(root(), "ultimo-stato.json");
  return fs.existsSync(f) ? { text: fs.readFileSync(f, "utf8") } : {};
});
ipcMain.handle("readBinary", (_e, p) => fs.readFileSync(p));
ipcMain.handle("getDriver", () => cfg.driver || "shared");
ipcMain.handle("setDriver", (_e, a) => {
  const c = readCfg();
  c.driver = a && a.driver;
  writeCfg(c);
  app.relaunch();
  app.exit(0);
});
ipcMain.handle("openSound", () => { exec("control.exe mmsys.cpl"); return {}; });

// ---- uscita ASIO (processo separato con PortAudio) ----
const asioDll = () => path.join(process.resourcesPath, "asio", "libportaudio64bit-asio.dll");
let asioP = null, rid = 0;
const waiters = new Map();
function asioStart() {
  if (asioP) return true;
  if (!fs.existsSync(asioDll())) return false;
  const script = path.join(__dirname, "asio-proc.js").replace("app.asar" + path.sep, "app.asar.unpacked" + path.sep);
  asioP = utilityProcess.fork(script);
  asioP.on("message", (m) => { const w = waiters.get(m.id); if (w) { waiters.delete(m.id); m.ok ? w.res(m.result) : w.rej(new Error(m.error)); } });
  asioP.on("exit", () => { asioP = null; for (const w of waiters.values()) w.rej(new Error("processo ASIO terminato")); waiters.clear(); });
  return true;
}
function asioCall(msg) {
  return new Promise((res, rej) => {
    if (!asioStart()) return rej(new Error("libreria ASIO non trovata in questa versione"));
    const id = ++rid;
    waiters.set(id, { res, rej });
    asioP.postMessage(Object.assign({ id }, msg));
    setTimeout(() => { if (waiters.delete(id)) rej(new Error("il driver ASIO non risponde")); }, 30000);
  });
}
ipcMain.handle("asioInfo", async () => {
  if (!fs.existsSync(asioDll())) return { ok: false };
  try { await asioCall({ cmd: "init", dll: asioDll() }); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle("asioDevices", async () => { await asioCall({ cmd: "init", dll: asioDll() }); return asioCall({ cmd: "devices" }); });
ipcMain.handle("asioOpen", async (_e, a) => { await asioCall({ cmd: "init", dll: asioDll() }); return asioCall(Object.assign({ cmd: "open" }, a)); });
ipcMain.on("asio:data", (_e, buf) => {
  if (!asioP) return;
  const ab = buf instanceof ArrayBuffer ? buf : buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  asioP.postMessage({ cmd: "data", buf: ab });
});
app.on("before-quit", () => { if (asioP) { try { asioP.kill(); } catch (e) {} } });

function createWindow() {
  win = new BrowserWindow({
    width: 1100, height: 820, minWidth: 420, minHeight: 600,
    backgroundColor: "#141416", title: "Cue List",
    icon: path.join(__dirname, "build", "icon.png"), autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true, nodeIntegration: false, backgroundThrottling: false
    }
  });
  win.loadFile(path.join(__dirname, "www", "index.html"));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: "deny" }; });
  win.webContents.on("will-prevent-unload", (e) => e.preventDefault());
}

app.whenReady().then(() => {
  const ok = ["media", "midi", "audioCapture"];
  session.defaultSession.setPermissionRequestHandler((_wc, perm, cb) => cb(ok.includes(perm)));
  session.defaultSession.setPermissionCheckHandler((_wc, perm) => ok.includes(perm));
  Menu.setApplicationMenu(null);
  createWindow();
});
app.on("window-all-closed", () => app.quit());
