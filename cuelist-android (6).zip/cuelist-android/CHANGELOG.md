# Changelog – Cue List

Le modifiche sono elencate dalla più recente alla più vecchia.

## 9 novembre 2026
### Aggiunto
- **Ricollegamento per cartella**: quando un brano non viene trovato, tocca la ✕ rossa e scegli la cartella dei brani. L'app cerca per nome (anche nelle sottocartelle) tutti i brani mancanti e ricostruisce da sola la cue list. Se il file non è nella cartella, ti chiede di sceglierlo a mano.
- **Cartelle ricordate**: le cartelle scelte restano autorizzate; aprendo uno show l'app le usa in automatico per trovare i brani.
- **Spettro per ogni cue** (forma d'onda con le parti fuori da inizio/fine attenuate e cursore durante la riproduzione). In ⚙ Impostazioni → *Spettro delle cue*: casella per attivarlo e scelta tra "solo in modalità edit" e "anche in modalità show" (non cliccabile).
- **File CHANGELOG** incluso nello zip a ogni aggiornamento.

### Modificato
- La ✕ rossa ora apre la scelta della cartella invece del singolo file; il singolo file resta come ripiego.

## 8 novembre 2026
### Aggiunto
- **Salvataggio show su file** (finestra "Salva con nome": Download, Drive…) e apertura da file; rimossa la casella di testo.
- **Libreria audio interna**: i brani importati vengono copiati nell'app e ricollegati da soli all'apertura di uno show; ✕ rossa accanto al nome se un file manca (anche per il file Click).
- **Installazione degli aggiornamenti dall'app**: tasto *Scarica e installa* con avanzamento e installazione guidata da Android.
- **Logo G sbarrata** come icona dell'app, nell'intestazione e nella pagina About.
- **Modalità Dual mono** con volume L/R per cue, master separati per Base L e Base R, pan per canale.
- **Pagina About**: invito all'open source, link al codice e ringraziamenti. Aggiunta licenza MIT.
- **Aggiornamenti automatici (OTA)** dalle Release di GitHub, versione installata e tasto ⚙ Impostazioni.
- Firma fissa dell'APK, così le nuove versioni si installano sopra le vecchie.

### Modificato
- In modalità Show il nome della cue non è modificabile e si seleziona toccando in qualsiasi punto della riga.
- Tasti di aggiunta cue e tasti di modifica su due righe diverse.
- *Uscita audio e MIDI* e *Salva / apri show* spostati nelle Impostazioni.
- Cestino 🗑 per eliminare una cue (la ✕ rossa indica ora un file mancante).

## 8 novembre 2026 – prima versione
- Lista di cue con grande tasto **GO**, **PANIC**, avanti e indietro.
- Fade in e fade out, volume per cue, loop, inizio e fine, pre-wait, post-wait, Auto-continue e Auto-follow.
- Cue di tipo Fade, Stop e Gruppo; tasti rapidi; annulla e ripeti; riordino con trascinamento.
- Tre canali: Base L, Base R e Click, con meter e test canali.
- Trigger MIDI, modalità Show, salvataggio e apertura degli show.
