# Cue List (Android)

App Android (Capacitor) con la cue list in stile QLab.

## Configurazione (una volta sola)
1. Repository pubblico su GitHub con questo zip (nome `cuelist-android.zip`) nella radice.
2. Settings > Secrets and variables > Actions: crea il secret `KEYSTORE_PASSWORD` con una password lunga e casuale.
3. Crea `.github/workflows/build.yml` con il workflow fornito (non cambiare mai il nome del file).

## Aggiornare l'app
Carica un nuovo zip con lo stesso nome: parte la build, viene firmata con la stessa chiave e pubblicata come Release. L'app installata controlla le Release all'avvio (e ogni 30 minuti) e mostra il pulsante "Scarica e installa". Si installa sopra la versione precedente.

## Note
- Tutta l'app e in `www/index.html`.
- Non perdere/cambiare `KEYSTORE_PASSWORD` e `release.keystore`: senza la stessa chiave Android rifiuta l'aggiornamento.

## Icona
L'icona dell'app (logo G sbarrata) e in `android-res/`: viene copiata nel progetto Android dopo `cap sync` (hook in `package.json`). Originali in `resources/`.

## Aggiornamento dentro l'app
`android-src/CueUpdater.java` scarica l'APK dalla Release e lo installa con il PackageInstaller di Android (`scripts/after-sync.sh` lo copia nel progetto e aggiunge il permesso REQUEST_INSTALL_PACKAGES).

## Libreria audio e show
I brani importati vengono copiati nella cartella interna dell'app (`files/audio`). Il file show (.json) salvato contiene nome e percorso di ogni brano: all'apertura l'app li cerca da sola; se un file manca compare una ✕ rossa per indicare il nuovo percorso.

## Changelog
Vedi `CHANGELOG.md`.
