package com.cuelist.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.annotation.ActivityCallback;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@CapacitorPlugin(name = "CueUpdater")
public class CueUpdater extends Plugin {
    private static final String ACTION = "com.cuelist.app.INSTALL_RESULT";
    private boolean registered = false;

    private void ensureReceiver() {
        if (registered) return;
        Context c = getContext();
        BroadcastReceiver r = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent i) {
                int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) {
                        confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ctx.startActivity(confirm);
                    }
                } else if (st != PackageInstaller.STATUS_SUCCESS) {
                    JSObject o = new JSObject();
                    o.put("status", st);
                    o.put("message", i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE));
                    notifyListeners("error", o);
                }
            }
        };
        IntentFilter f = new IntentFilter(ACTION);
        if (Build.VERSION.SDK_INT >= 33) {
            c.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            c.registerReceiver(r, f);
        }
        registered = true;
    }

    @PluginMethod
    public void install(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null) {
            call.reject("url mancante");
            return;
        }
        ensureReceiver();
        new Thread(() -> {
            try {
                File apk = new File(getContext().getCacheDir(), "update.apk");
                HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
                con.setInstanceFollowRedirects(true);
                con.setConnectTimeout(15000);
                con.setReadTimeout(30000);
                con.setRequestProperty("User-Agent", "CueList");
                int total = con.getContentLength();
                long done = 0;
                int lastPct = -1;
                try (InputStream in = con.getInputStream(); OutputStream out = new FileOutputStream(apk)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        done += n;
                        if (total > 0) {
                            int p = (int) (done * 100 / total);
                            if (p != lastPct) {
                                lastPct = p;
                                JSObject o = new JSObject();
                                o.put("percent", p);
                                notifyListeners("progress", o);
                            }
                        }
                    }
                }
                PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
                PackageInstaller.SessionParams params =
                    new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                if (Build.VERSION.SDK_INT >= 31) {
                    params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
                }
                int id = pi.createSession(params);
                try (PackageInstaller.Session s = pi.openSession(id)) {
                    try (InputStream in = new FileInputStream(apk);
                         OutputStream out = s.openWrite("update", 0, apk.length())) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                        }
                        s.fsync(out);
                    }
                    Intent intent = new Intent(ACTION).setPackage(getContext().getPackageName());
                    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                    if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
                    PendingIntent pend = PendingIntent.getBroadcast(getContext(), id, intent, flags);
                    s.commit(pend.getIntentSender());
                }
                call.resolve();
            } catch (Exception e) {
                call.reject(e.getMessage() == null ? e.toString() : e.getMessage());
            }
        }).start();
    }

    // ---- libreria audio e salvataggio show ----
    private String displayName(Uri u) {
        String name = null;
        try (Cursor c = getContext().getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0) name = c.getString(ix);
            }
        } catch (Exception e) { }
        if (name == null || name.isEmpty()) name = "audio-" + System.currentTimeMillis();
        return name.replace("/", "_");
    }

    @PluginMethod
    public void pickAudio(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, call.getBoolean("multiple", false));
        startActivityForResult(call, i, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            call.reject("annullato");
            return;
        }
        final Intent d = result.getData();
        new Thread(() -> {
            try {
                List<Uri> uris = new ArrayList<>();
                if (d.getClipData() != null) {
                    for (int k = 0; k < d.getClipData().getItemCount(); k++) {
                        uris.add(d.getClipData().getItemAt(k).getUri());
                    }
                } else if (d.getData() != null) {
                    uris.add(d.getData());
                }
                File dir = new File(getContext().getFilesDir(), "audio");
                dir.mkdirs();
                JSArray arr = new JSArray();
                for (Uri u : uris) {
                    String name = displayName(u);
                    File out = new File(dir, name);
                    try (InputStream in = getContext().getContentResolver().openInputStream(u);
                         OutputStream os = new FileOutputStream(out)) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                    }
                    JSObject o = new JSObject();
                    o.put("name", name);
                    o.put("path", out.getAbsolutePath());
                    arr.put(o);
                }
                JSObject res = new JSObject();
                res.put("files", arr);
                call.resolve(res);
            } catch (Exception e) {
                call.reject(e.getMessage() == null ? e.toString() : e.getMessage());
            }
        }).start();
    }

    @PluginMethod
    public void findAudio(PluginCall call) {
        String name = call.getString("name");
        JSObject res = new JSObject();
        if (name != null) {
            File f = new File(new File(getContext().getFilesDir(), "audio"), name.replace("/", "_"));
            if (f.exists()) res.put("path", f.getAbsolutePath());
        }
        call.resolve(res);
    }

    @PluginMethod
    public void saveFile(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, call.getString("name", "show.json"));
        startActivityForResult(call, i, "saveResult");
    }

    @ActivityCallback
    private void saveResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("annullato");
            return;
        }
        try (OutputStream os = getContext().getContentResolver().openOutputStream(result.getData().getData(), "wt")) {
            os.write(call.getString("text", "").getBytes("UTF-8"));
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    // ---- cartelle: cerca i brani mancanti per nome ----
    private List<String> namesOf(PluginCall call) {
        List<String> l = new ArrayList<>();
        JSArray a = call.getArray("names");
        if (a != null) {
            for (int k = 0; k < a.length(); k++) l.add(a.optString(k));
        }
        return l;
    }

    private Set<String> folderSet() {
        return new HashSet<String>(getContext().getSharedPreferences("cuelist", Context.MODE_PRIVATE)
            .getStringSet("folders", new HashSet<String>()));
    }

    private void scan(Uri tree, String docId, Set<String> wanted, File dir, JSArray out, Set<String> done, int depth) {
        if (depth > 6) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] cols = new String[] {
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        };
        try (Cursor c = getContext().getContentResolver().query(children, cols, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    scan(tree, id, wanted, dir, out, done, depth + 1);
                } else if (name != null && wanted.contains(name.toLowerCase()) && !done.contains(name.toLowerCase())) {
                    try {
                        Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                        File f = new File(dir, name.replace("/", "_"));
                        try (InputStream in = getContext().getContentResolver().openInputStream(doc);
                             OutputStream os = new FileOutputStream(f)) {
                            byte[] buf = new byte[65536];
                            int n;
                            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                        }
                        done.add(name.toLowerCase());
                        JSObject o = new JSObject();
                        o.put("name", name);
                        o.put("path", f.getAbsolutePath());
                        out.put(o);
                    } catch (Exception e) { }
                }
            }
        } catch (Exception e) { }
    }

    private JSObject scanTrees(List<Uri> trees, List<String> names) {
        Set<String> wanted = new HashSet<>();
        for (String n : names) wanted.add(n.toLowerCase());
        File dir = new File(getContext().getFilesDir(), "audio");
        dir.mkdirs();
        JSArray out = new JSArray();
        Set<String> done = new HashSet<>();
        for (Uri t : trees) {
            try {
                scan(t, DocumentsContract.getTreeDocumentId(t), wanted, dir, out, done, 0);
            } catch (Exception e) { }
        }
        JSObject res = new JSObject();
        res.put("files", out);
        return res;
    }

    @PluginMethod
    public void pickFolder(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        startActivityForResult(call, i, "folderResult");
    }

    @ActivityCallback
    private void folderResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("annullato");
            return;
        }
        final Uri tree = result.getData().getData();
        try {
            getContext().getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Set<String> s = folderSet();
            s.add(tree.toString());
            getContext().getSharedPreferences("cuelist", Context.MODE_PRIVATE).edit().putStringSet("folders", s).apply();
        } catch (Exception e) { }
        final List<String> names = namesOf(call);
        new Thread(() -> {
            List<Uri> one = new ArrayList<>();
            one.add(tree);
            call.resolve(scanTrees(one, names));
        }).start();
    }

    @PluginMethod
    public void scanSaved(PluginCall call) {
        final List<String> names = namesOf(call);
        new Thread(() -> {
            List<Uri> trees = new ArrayList<>();
            for (String x : folderSet()) trees.add(Uri.parse(x));
            call.resolve(scanTrees(trees, names));
        }).start();
    }
}
