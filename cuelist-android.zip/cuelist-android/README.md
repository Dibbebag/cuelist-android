# Cue List (Android)

App Android (Capacitor) che racchiude la cue list in stile QLab: GO, Panic, fade, pre/post-wait, gruppi, Base L/R + Click.

## Come ottenere l'APK
1. Crea un repository su GitHub e carica **tutto il contenuto** di questa cartella (compresa la cartella nascosta `.github`).
2. Vai su **Actions** > **Build APK** > **Run workflow** (parte anche da solo a ogni push su main).
3. Quando finisce (circa 5 minuti), apri l'esecuzione e scarica **cuelist-apk** dagli Artifacts. Dentro c'è `app-debug.apk`.
4. Copia l'APK sul dispositivo e installalo (consenti "installa da origini sconosciute").

## Modificare l'app
Tutta l'app è in `www/index.html`. Modifica quel file, fai commit e l'APK si ricompila.

## Note
- Il WebView Android di solito espone solo uscita stereo: il canale Click separato richiede un dispositivo/driver che esponga 3+ canali.
- MIDI e cambio dispositivo di uscita possono non essere disponibili nel WebView.
- Salvataggio: autosalvataggio locale + Esporta/Importa JSON. I file audio vanno ricaricati.
