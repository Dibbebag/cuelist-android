set -e
# icone
cp -r android-res/. android/app/src/main/res/
# plugin di aggiornamento
D=android/app/src/main/java/com/cuelist/app
mkdir -p "$D"
cp android-src/*.java "$D/"
# permesso per installare aggiornamenti
M=android/app/src/main/AndroidManifest.xml
grep -q REQUEST_INSTALL_PACKAGES "$M" || sed -i 's#</manifest>#    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n</manifest>#' "$M"
