// Crea latest.yml (descrizione dell'ultima versione per l'aggiornamento automatico)
const crypto = require("crypto");
const fs = require("fs");
const build = process.argv[2];
const file = "dist/CueList-Setup.exe";
const data = fs.readFileSync(file);
const sha = crypto.createHash("sha512").update(data).digest("base64");
const yml = [
  "version: 1.0." + build,
  "files:",
  "  - url: CueList-Setup.exe",
  "    sha512: " + sha,
  "    size: " + data.length,
  "path: CueList-Setup.exe",
  "sha512: " + sha,
  "releaseDate: '" + new Date().toISOString() + "'",
  ""
].join("\n");
fs.writeFileSync("dist/latest.yml", yml);
console.log(yml);
