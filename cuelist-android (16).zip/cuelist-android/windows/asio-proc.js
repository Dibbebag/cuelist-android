// Processo separato: scrive l'audio sull'uscita ASIO tramite PortAudio (libreria con ASIO)
const koffi = require("koffi");
const port = process.parentPort;
let F = null, stream = null, running = false, queue = [], pending = 0, ch = 2;
const BLOCK = 512;

function load(dll) {
  if (F) return;
  const lib = koffi.load(dll);
  koffi.struct("PaDeviceInfo", { structVersion: "int", name: "const char *", hostApi: "int", maxInputChannels: "int", maxOutputChannels: "int", defaultLowInputLatency: "double", defaultLowOutputLatency: "double", defaultHighInputLatency: "double", defaultHighOutputLatency: "double", defaultSampleRate: "double" });
  koffi.struct("PaHostApiInfo", { structVersion: "int", type: "int", name: "const char *", deviceCount: "int", defaultInputDevice: "int", defaultOutputDevice: "int" });
  koffi.struct("PaStreamParameters", { device: "int", channelCount: "int", sampleFormat: "uint32", suggestedLatency: "double", hostApiSpecificStreamInfo: "void *" });
  F = {
    init: lib.func("int Pa_Initialize()"),
    term: lib.func("int Pa_Terminate()"),
    count: lib.func("int Pa_GetDeviceCount()"),
    dev: lib.func("const PaDeviceInfo *Pa_GetDeviceInfo(int d)"),
    host: lib.func("const PaHostApiInfo *Pa_GetHostApiInfo(int h)"),
    open: lib.func("int Pa_OpenStream(_Out_ void **s, const PaStreamParameters *i, const PaStreamParameters *o, double rate, uint32 frames, uint32 flags, void *cb, void *ud)"),
    start: lib.func("int Pa_StartStream(void *s)"),
    stop: lib.func("int Pa_StopStream(void *s)"),
    close: lib.func("int Pa_CloseStream(void *s)"),
    write: lib.func("int Pa_WriteStream(void *s, const void *b, uint32 frames)"),
    err: lib.func("const char *Pa_GetErrorText(int e)")
  };
  F.init();
}
const check = (e) => { if (e < 0) throw new Error(F.err(e)); };

function devices() {
  closeStream();
  F.term(); F.init(); // rilegge i driver installati
  const out = [], n = F.count();
  for (let i = 0; i < n; i++) {
    const d = F.dev(i);
    if (!d || d.maxOutputChannels <= 0) continue;
    const h = F.host(d.hostApi);
    if (h && h.type === 3) out.push({ id: i, name: d.name, channels: d.maxOutputChannels, rate: d.defaultSampleRate });
  }
  return out;
}

function closeStream() {
  running = false;
  if (stream) { try { F.stop(stream); F.close(stream); } catch (e) {} stream = null; }
  queue = []; pending = 0;
}

function openStream(a) {
  closeStream();
  ch = a.channels;
  const info = F.dev(a.device);
  const out = [null];
  const p = { device: a.device, channelCount: ch, sampleFormat: 1, suggestedLatency: info ? info.defaultLowOutputLatency : 0.05, hostApiSpecificStreamInfo: null };
  check(F.open(out, null, p, a.rate, 0, 0, null, null));
  stream = out[0];
  check(F.start(stream));
  running = true;
  tick();
}

function tick() {
  if (!running) return;
  const need = BLOCK * ch;
  const buf = new Float32Array(need);
  if (pending > BLOCK * 40) { // deriva tra i due clock: riallinea
    while (pending > BLOCK * 8 && queue.length) { const c = queue.shift(); pending -= (c.a.length - c.pos) / ch; }
  }
  if (pending >= BLOCK) {
    let o = 0;
    while (o < need) {
      const c = queue[0], take = Math.min(c.a.length - c.pos, need - o);
      buf.set(c.a.subarray(c.pos, c.pos + take), o);
      o += take; c.pos += take;
      if (c.pos >= c.a.length) queue.shift();
    }
    pending -= BLOCK;
  }
  try { F.write(stream, buf, BLOCK); } catch (e) { running = false; return; }
  setImmediate(tick);
}

const toAB = (b) => (b instanceof ArrayBuffer ? b : b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));

port.on("message", (e) => {
  const m = e.data;
  if (m.cmd === "data") {
    if (running) { const a = new Float32Array(toAB(m.buf)); queue.push({ a, pos: 0 }); pending += a.length / ch; }
    return;
  }
  const reply = (ok, v) => port.postMessage(ok ? { id: m.id, ok: true, result: v } : { id: m.id, ok: false, error: String((v && v.message) || v) });
  try {
    if (m.cmd === "init") { load(m.dll); reply(true, { ok: true }); }
    else if (m.cmd === "devices") { reply(true, devices()); }
    else if (m.cmd === "open") { openStream(m); reply(true, { ok: true }); }
    else if (m.cmd === "close") { closeStream(); reply(true, { ok: true }); }
  } catch (err) { reply(false, err); }
});
