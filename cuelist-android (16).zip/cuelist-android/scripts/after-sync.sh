set -e
# icone
cp -r android-res/. android/app/src/main/res/
# plugin di aggiornamento
D=android/app/src/main/java/com/cuelist/app
mkdir -p "$D"
cp android-src/*.java "$D/"
# permesso per installare aggiornamenti
M=android/app/src/main/AndroidManifest.xml
grep -q REQUEST_INSTALL_PACKAGES "$M" || sed -i 's#</manifest>#    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n</manifest>#' "$M"
# evita che la build si fermi se il download di Gradle e lento (limite predefinito: 10 secondi)
W=android/gradle/wrapper/gradle-wrapper.properties
if [ -f "$W" ]; then
  if grep -q '^networkTimeout=' "$W"; then sed -i 's/^networkTimeout=.*/networkTimeout=120000/' "$W"; else echo 'networkTimeout=120000' >> "$W"; fi
fi
# schermata di avvio (splash): sostituisce tutte le immagini predefinite con il logo
for f in $(find android/app/src/main/res -name 'splash.png'); do cp resources/splash.png "$f"; done
