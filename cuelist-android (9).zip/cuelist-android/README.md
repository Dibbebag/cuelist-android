# Cue List

Cue List è un'app per lanciare audio dal vivo con una **lista di cue**: un grande tasto **GO**, il tasto **PANIC**, fade, tempi di attesa, gruppi, uscite separate per Base e Click, spettro del brano e molto altro. È pensata per teatro, musica dal vivo, eventi e sonorizzazioni. Gira come app Android e anche in un normale browser (Chrome).

Questa app è software libero (licenza MIT): usala, studiala, modificala e condividila. Il codice è su https://github.com/Dibbebag/cuelist-android

---

## 1. Schermata principale

- **GO** (barra spaziatrice): lancia la cue selezionata e sposta la selezione alla successiva. Se la cue ha un Auto-continue o un Auto-follow, parte anche la catena di cue collegate.
- **◀ Indietro / Avanti ▶** (frecce ↑ ↓): spostano la selezione senza lanciare nulla.
- **PANIC** (tasto Esc): ferma tutto con un fade di 0,25 secondi e annulla anche le cue in attesa di partire.
- **Mixer in alto**: fader master e indicatori di livello (meter) delle uscite.
- **Lista delle cue**: la cue selezionata ha il bordo blu, quella in riproduzione diventa verde con una barra di avanzamento. Tocca in un punto qualsiasi di una cue per selezionarla.
- **Saltare dentro una cue** (solo in modalità edit): mentre una cue suona, tocca o **trascina** la barra verde di avanzamento in fondo alla cue (o la forma d'onda, se attiva) per spostare la riproduzione avanti o indietro. In modalità Show non è cliccabile.
- **Messaggi**: sotto il mixer compaiono avvisi, per esempio i brani non trovati.
- **⚙ Impostazioni** e **🔒 Show** in alto a destra.

## 2. Tipi di cue

Si aggiungono con i tasti della prima riga: **+ Audio**, **+ Fade**, **+ Stop**, **+ Gruppo**.

- **Audio**: riproduce un file. Si possono caricare più file insieme: ognuno diventa una cue. Formati supportati: quelli letti dal dispositivo (WAV, MP3, AAC, FLAC, OGG...).
- **Fade**: porta una cue in riproduzione a un nuovo livello (da 0 a 1,5 volte il suo volume) in un tempo scelto; con **Ferma** la cue si spegne alla fine del fade.
- **Stop**: ferma una cue (o tutte, scegliendo *Tutte*) con un fade.
- **Gruppo**: lancia insieme le N cue successive (numero a scelta).

## 3. Impostazioni di ogni cue

Valide per tutte le cue:
- **Nome** modificabile; numero, tipo e durata.
- **Pre-wait**: secondi di attesa prima che la cue parta.
- **Auto**: *Nessuno*, *Continue* (la cue successiva parte dopo il **Post-wait**) oppure *Follow* (la successiva parte quando questa finisce).
- **Tasto**: una lettera per lanciare la cue direttamente dalla tastiera, senza spostare la selezione.
- **■** ferma la cue con un fade (usa il suo fade out, o 1 secondo).
- **↑ ↓** e **trascinamento** (⋮⋮) per riordinare; **🗑** per eliminare (richiede una seconda conferma).

Solo per le cue Audio:
- **Fade in** e **Fade out** in secondi (il fade out si applica alla fine del brano).
- **Inizio** e **Fine**: tagliano il brano (Fine = 0 significa fino in fondo).
- **Loop** ripete la parte tra Inizio e Fine finché non la fermi.
- **Volume** e **Pan** per cue, sotto i cursori del volume (vedi sotto per il Dual mono).
- **Click**: associa un file separato per il canale Click.
- **Spettro** del brano (se attivato nelle impostazioni).

## 4. Audio e canali

Nelle impostazioni, in *Uscita audio e MIDI*, scegli la **Modalità**:

- **Dual mono (2 uscite)**: i due canali del file sono indipendenti. Un file stereo manda il canale 1 sul *Canale L* e il canale 2 sul *Canale R*; un file mono va su entrambi. Ogni canale ha **fader** e **meter** nel mixer, e ogni cue ha **Vol L** e **Vol R** con, sotto, **Pan L** e **Pan R** per posizionare ciascun canale nel campo stereo. Utile per esempio con base su un canale e click sull'altro.
- **Base L/R + Click (3 uscite)**: la base va su due uscite (L e R) e il Click su una terza. Il mixer ha un fader per la Base e uno per il Click, e ogni cue ha un solo **Vol** e un **Pan** per la base. Un file a 3 canali viene diviso da solo: canale 1 = L, canale 2 = R, canale 3 = Click.

Altre opzioni:
- **Dispositivo**: scelta dell'uscita audio (dove supportato).
- **Primo canale**: numero della prima uscita da usare, utile con schede audio con molte uscite.
- **Test canali**: riproduce un tono su ogni uscita per controllare i collegamenti.
- Riga **Canali disponibili**: dice quante uscite vede il dispositivo.
- Se il dispositivo ha almeno 3 uscite e non hai scelto altro, parte da solo la modalità a 3 canali.

## 5. Spettro delle cue

In ⚙ Impostazioni → *Spettro delle cue*:
- una casella attiva la **forma d'onda** di ogni cue audio, con le parti fuori da Inizio/Fine attenuate e un cursore durante la riproduzione;
- una scelta decide se mostrarla **solo in modalità edit** oppure **anche in modalità show** (dove è visibile ma non cliccabile).

## 6. Modalità Show

Il tasto **🔒 Show** blocca le modifiche per evitare errori dal vivo: nascondono i tasti di aggiunta e modifica, i parametri delle cue e le impostazioni di uscita; il nome non si può cambiare e si seleziona la cue toccando in qualsiasi punto della riga. Restano disponibili GO, PANIC, avanti/indietro, ■ di ogni cue e, se manca un brano, la ✕ rossa per ricollegarlo. Premi di nuovo il tasto per tornare in modifica.

**Volumi in tempo reale, anche in Show**: durante le prove puoi aprire ⚙ Impostazioni → *Volumi cue in tempo reale* senza uscire dalla modalità Show. Le cue in riproduzione sono in cima, segnate con ▶: muovendo i cursori il volume cambia subito mentre l'audio suona (un cursore per canale in Dual mono, uno solo nella modalità a 3 uscite). Anche i **pan** delle cue si regolano lì; il master di ciascun canale è nel mixer in alto, sempre disponibile. Anche i cursori di volume nella riga di ogni cue (in modalità edit) agiscono subito.

## 7. Salvare e aprire uno show

In ⚙ Impostazioni → *Salva / apri show*:
- **💾 Salva show su file** crea un file `.json` nel punto che scegli (Download, Drive...), che puoi spostare, copiare o condividere.
- **📂 Apri show da file** carica uno show salvato.
- Lo show corrente viene anche **salvato in automatico** nel dispositivo: chiudendo e riaprendo l'app riparte con **l'ultima scaletta** così com'era, con la selezione nella stessa posizione e i brani ricollegati da soli. Una copia di sicurezza dell'ultimo stato è anche nella cartella `CueList`.
- **Autosalvataggio**: in ⚙ Impostazioni → *Cartella dell'app, autosalvataggi e show* scegli ogni quanto salvare (5, 10, 15, 30 o 60 minuti, oppure disattivato; predefinito 30). Avviene in silenzio, senza avvisi, e solo se lo show è cambiato; si conservano gli ultimi 10.
- **Cartella dell'app**: l'app crea la cartella `CueList` con tre sottocartelle: `Show` (gli show che salvi), `Brani` (i brani importati) e `Autosalvataggi`. Nelle impostazioni vedi il percorso e gli elenchi di autosalvataggi e show salvati, da cui riapri uno show con un tocco. Ogni volta che usi **Salva show su file** una copia viene messa anche in `Show`.
- **↶ Annulla** e **↷ Ripeti** (fino a 100 passaggi) e **Nuovo** per svuotare la lista (con conferma).

## 8. Brani e ricollegamento automatico

- I brani importati con **+ Audio** vengono **copiati nella cartella `Brani` dell'app**, quindi restano disponibili anche se il file originale viene spostato.
- Aprendo uno show, l'app cerca da sola i brani: prima nel percorso salvato, poi per nome tra quelli già importati, poi nelle cartelle che hai già autorizzato.
- Mentre i brani si caricano compare una clessidra ⏳ accanto al nome: la ✕ rossa compare solo se un file non si trova davvero.
- Se un brano non si trova compare una **✕ rossa** accanto al nome. Toccala e **scegli la cartella dei brani**: l'app cerca per nome (anche nelle sottocartelle) tutti i brani mancanti e ricostruisce da sola la lista. Se il file non è in quella cartella, ti chiede di scegliere il brano a mano.
- Le cartelle scelte restano autorizzate per i prossimi show.
- Funziona allo stesso modo per i file Click.

## 9. Scorciatoie e MIDI

Da tastiera: **Spazio** = GO, **Esc** = PANIC, **↑ ↓** = selezione, **Ctrl+Z** = annulla, **Ctrl+Maiusc+Z** o **Ctrl+Y** = ripeti, e la lettera assegnata a ogni cue.

**MIDI** (nei browser che lo supportano; non è disponibile nell'app Android): in *Uscita audio e MIDI* premi **Attiva MIDI**. Le note predefinite sono 60 = GO, 61 = PANIC, 62 = Avanti, 63 = Indietro; toccando il tasto di ciascuna azione e premendo una nota sul controller puoi cambiarla.

## 10. Impostazioni, aggiornamenti e informazioni

La pagina ⚙ Impostazioni è organizzata in quest'ordine: **Salva**, **Cartella dell'app**, **Uscita audio**, **Spettro delle cue**, **Volumi e pan in tempo reale**, **Crediti** e, in fondo, **Versione** con la ricerca degli aggiornamenti.

- Nell'app Android, all'avvio e ogni 30 minuti, viene controllata la presenza di una nuova versione. Se c'è, compare una barra blu in alto con **Scarica e installa**; lo stesso tasto è in ⚙ Impostazioni, insieme a **Cerca aggiornamenti** e al **numero di versione**.
- L'app scarica l'aggiornamento e lo passa all'installazione di Android, che può chiedere una conferma. Al primo uso va consentito all'app di installare app sconosciute. Dopo l'installazione Android chiude l'app: riaprila.
- La pagina **Info e crediti** contiene il logo, l'invito all'open source, il link al codice e i ringraziamenti.

## 11. Limiti noti

- Su telefoni e tablet Android l'audio passa dal browser integrato (WebView), che di solito offre solo 2 uscite: con una scheda audio multicanale il numero di uscite visibili dipende da Android. Controlla la riga *Canali disponibili*.
- MIDI e scelta del dispositivo di uscita possono non essere disponibili nell'app Android.
- Le copie dei brani occupano spazio nel dispositivo e vengono cancellate se disinstalli l'app.
- Aprendo lo show su un altro dispositivo i brani vanno ricollegati una volta con la ✕ rossa.
- Saltando dentro una cue, i tempi di Auto-follow già programmati non si spostano.
- Inizio, Fine, fade e loop di una cue valgono dal lancio successivo; volumi e pan delle cue si cambiano invece in tempo reale.
- Su Android 11 e successivi alcune app per i file non mostrano la cartella `Android/data` in cui si trova `CueList`: per portare uno show fuori dal telefono usa **Salva show su file**.

---

## Per sviluppatori

### Configurazione (una volta sola)
1. Repository **pubblico** su GitHub con questo zip nella radice.
2. Settings → Secrets and variables → Actions: crea il secret `KEYSTORE_PASSWORD` con una password lunga e casuale.
3. Crea `.github/workflows/build.yml` con il workflow fornito (non cambiare mai il nome del file).

### Aggiornare l'app
Carica un nuovo zip: parte la build, viene firmata con la stessa chiave e pubblicata come Release. L'app installata la propone da sola. Non perdere né cambiare `KEYSTORE_PASSWORD` e `release.keystore`: senza la stessa chiave Android rifiuta l'aggiornamento.

### Struttura
- `www/index.html`: tutta l'interfaccia e la logica audio (HTML, CSS e JavaScript, Web Audio API).
- `android-src/`: plugin Android (`CueUpdater.java`): installazione degli aggiornamenti, selezione dei brani e delle cartelle, salvataggio dei file, cartella `CueList` e autosalvataggi.
- `android-res/` e `resources/`: icona dell'app (logo G sbarrata).
- `scripts/after-sync.sh`: copia icone e plugin nel progetto Android dopo `cap sync` (hook in `package.json`).
- `CHANGELOG.md`: elenco delle modifiche a ogni aggiornamento.
- `LICENSE`: licenza MIT.

---

*Questo README descrive tutte le funzioni dell'app e viene aggiornato a ogni novità importante. Le modifiche, versione per versione, sono nel file `CHANGELOG.md`.*
